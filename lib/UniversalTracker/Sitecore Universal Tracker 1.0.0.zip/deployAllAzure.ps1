param(
    [Parameter(Mandatory = $True)]
    [string]
    $subscriptionId,
    
    [Parameter(Mandatory = $True)]
    [string]
    $azureSecurityKey,
    
    [Parameter(Mandatory = $True)]
    [string]
    $azureClientID,
    
    [Parameter(Mandatory = $True)]
    [string]
    $azureTenantID,

    [Parameter(Mandatory = $True)]
    [System.String]
    $targetServerName,

    [Parameter(Mandatory = $True)]
    [System.String]
    $targetDatabaseName,

    [Parameter(Mandatory = $True)]
    [System.String]
    $targetUser,

    [Parameter(Mandatory = $True)]
    [System.String]
    $targetUserPassword,

    [Parameter(Mandatory = $True)]
    [string]
    $licenseXmlPath,

    [Parameter(Mandatory=$true)]
    [string]
    $collectionWdpPackagePath,

    [Parameter(Mandatory=$true)]
    [string]
    $collectionInfrastructureDirPath,

    [Parameter(Mandatory=$true)]
    [string]
    $processingWdpPackagePath,

    [Parameter(Mandatory=$true)]
    [string]
    $processingInfrastructureDirPath,
    
    [Parameter(Mandatory=$true)]
    [string]
    $sourceDacFile,
    
    [Parameter(Mandatory=$true)]
    [string]
    $sqlInfrastructureDirPath,

    [string]
    $resourceGroupName = "scuniversaltracking-rg",
    
    [string]
    $resourceGroupLocation = "North Europe",
    
    [string]
    $storageContainerName = "scuniversaltracking-sa"
)
try {
    
$azureDeployScriptName = "azureDeploy.ps1";
$pathTodeployCollectionScript = Join-Path $collectionInfrastructureDirPath $azureDeployScriptName;
$pathTodeployProcessingScript = Join-Path $processingInfrastructureDirPath $azureDeployScriptName;
$pathTodeploySqlScript = Join-Path $sqlInfrastructureDirPath $azureDeployScriptName

Write-Host "START DEPLOYMENT OF SQL SERVER TO AZURE ...";

& $pathTodeploySqlScript -subscriptionId $subscriptionId `
    -azureSecurityKey $azureSecurityKey `
    -resourceGroupName $resourceGroupName `
    -resourceGroupLocation $resourceGroupLocation `
    -storageContainerName $storageContainerName `
    -azureClientID $azureClientID `
    -azureTenantID $azureTenantID `
    -sourceDacFile $sourceDacFile `
    -targetServerName $targetServerName `
    -targetDatabaseName $targetDatabaseName `
    -targetUser $targetUser `
    -targetUserPassword $targetUserPassword

function Get-SqlConnectionString {
    param (
        [string]$sqlServerName,
        [string]$sqlDatabaseName,
        [string]$sqlUserName,
        [string]$sqlUserPassword
    )
        
    return "Server=tcp:$sqlServerName.database.windows.net,1433;Initial Catalog=$sqlDatabaseName;Persist Security Info=False;User ID=$sqlUserName;Password=$sqlUserPassword;MultipleActiveResultSets=False;Encrypt=True;TrustServerCertificate=False;Connection Timeout=30;"
}

$connectionString = Get-SqlConnectionString -sqlServerName $targetServerName -sqlDatabaseName $targetDatabaseName -sqlUserName $targetUser -sqlUserPassword $targetUserPassword

Write-Host "START DEPLOYMENT OF PROCESSING SERVICE TO AZURE ...";

& $pathTodeployProcessingScript -subscriptionId $subscriptionId `
    -wdpPackagePath $processingWdpPackagePath `
    -resourceGroupName $resourceGroupName `
    -resourceGroupLocation $resourceGroupLocation `
    -storageContainerName $storageContainerName `
    -azureSecurityKey $azureSecurityKey `
    -azureClientID $azureClientID `
    -azureTenantID $azureTenantID `
    -licenseXmlPath $licenseXmlPath `
    -dbConnectionString $connectionString

Write-Host "START DEPLOYMENT OF COLLECTION SERVICE TO AZURE ...";

& $pathTodeployCollectionScript -subscriptionId $subscriptionId `
    -wdpPackagePath $collectionWdpPackagePath `
    -resourceGroupName $resourceGroupName `
    -resourceGroupLocation $resourceGroupLocation `
    -storageContainerName $storageContainerName `
    -azureSecurityKey $azureSecurityKey `
    -azureClientID $azureClientID `
    -azureTenantID $azureTenantID `
    -licenseXmlPath $licenseXmlPath `
    -dbConnectionString $connectionString

}
catch {
    Write-Error $_.Exception.Message
    Break
}
